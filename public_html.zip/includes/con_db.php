<?php

$conex = mysqli_connect("127.0.0.1:3306", "u814718208_beristain1", "Olivia2023", "u814718208_contacto");


?>