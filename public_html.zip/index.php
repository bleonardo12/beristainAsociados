

<!DOCTYPE html>
<html class="js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
	<head>
        	    <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-MLZ2VR5SYR">
        </script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'G-MLZ2VR5SYR');
        </script>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta charset="utf-8">
		<meta name="viewport" content="initial-scale=1.0, user-scalable=yes, viewport-fit=cover">
		<link rel="shortcut icon" href="/favicon.jpg">
		<link rel="manifest" href="/manifest.json">	
		<title>Beristain & Asociados Estudio Juridico</title>
		<meta name="title" content="Beristain & Asociados Estudio Juridico">
		<meta name="description" content="Beristain & Asociados Ej, Cont&#225;ctenos.">
		<meta name="keywords" content="Derecho, M&A, Fusiones y adquisiciones,	Law Firm, Abogados, Transaction, Estudio Jurídico, Deal, Transacciones,	Lawyers, Propiedad intelectual, Intellectual Property">
		<meta name="robots" content="index, follow">
		<meta name="google-site-verification" content="McRAfoykKbtfXsWWXmil-uSjpkXtpz4rm8p938BAWYM">
		<meta name="accept-language" content="es">
		<script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Jura:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Prata&family=Tilt+Prism&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;1,100;1,200;1,300;1,400;1,500&display=swap" rel="stylesheet">
		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="normalize.css?40.0" media="all">
		<link rel="stylesheet" type="text/css" href="styles.css?60.0" media="all">
		<!-- Bootstrap -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
				
	</head>
<body>	
	<main>	
		<nav class="navbar navbar-expand-lg">
				<a class="navbar-brand" href="#home"><img class="logo" src="img/logo.gif" alt=""></a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a class="nav-link active" aria-current="page" href="#home">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link active" href="#profesionales">Quienes Somos</a>
						</li>
						<li class="nav-item">
							<li class="nav-item dropdown">
								<a class="nav-link active dropdown-toggle" href="#areasDePractica" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
										Areas de práctica</a>
								<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
									<li><a class="dropdown-item" href="#dchoPenal">Derecho Penal</a></li>
									<li><a class="dropdown-item" href="#dchoCivil">Derecho Civil y Comercial</a></li>
									<li><a class="dropdown-item" href="#dchoFam">Derecho de Familia y Sucesiones</a></li>
									<li><a class="dropdown-item" href="#dchoSeguros">Seguros y Accidentes de tránsito</a></li>
									<li><a class="dropdown-item" href="#dchoLab">Derecho Laboral</a></li>
									<li><a class="dropdown-item" href="#dchoAdmin">Derecho Administrativo</a></li>
								</ul>
							</li>
							<a class="nav-link active" href="#novedades">Novedades</a>
						</li>
							<li class="nav-item">
								<a class="nav-link active" href="#contactanos" tabindex="-1" aria-disabled="false">Contacto</a>
							</li>
					</ul>
				</div>
		</nav>		
			
				<!-- presentacion -->	
				<div class="container">	
					<section class="home bg" id="home">	
						<div class="home-text">
							<div class="slide">
							</div><br>
							<h1>Beristain <span>&</span> Asociados</h1><br>
							<h3>Al tomar tu caso, nos comprometemos con<span> vos.</span></h3>
						</div>	  
					</section>
				</div>		
					<!-- seccion sobre profesionales -->
				<div class="container">
					<section class="row" id="profesionales">
						<div class="col">
							<h2 class="section-two">Sobre Nosotros</h2>
							<p class="col section-two-p">Somos un grupo de profesionales del derecho, orgullosos de ofrecerte un completo plan de asesoramiento jurídico, pensado y analizado pura y exclusivamente para vos, asegurándonos que tus intereses sean representados de manera total e íntegra.
								Nuestro estudio cuenta con profesionales altamente capacitados, especialistas en derecho público y en derecho privado, que abarca una amplia gama de áreas legales con el firme propósito de hacer valer los derechos de nuestros clientes y satisfacer sus necesidades. 
							</p>
						</div>	
					</section>
				</div>	
				<div class="slider-area">
					<div class="single-slider" style="background-image: url(img/slider-bg.jpg)">
						<div class="container">
							<div class="row align-items-center">	
								<div class="col">
									<div class="hero-content">
										<div class="title">	
											<h3 class="wrap">El estudio</h3>
										</div>
										<div class="description">
											<h4>Leonardo Beristain</h4>
											<h5 class="title-desing">Fundador del estudio y abogado novel recibido en la UBA. Especialidad en Derecho Penal.</h5>
											<p class="text-desing">Comprometido a dedicarme íntegramente a esta ílustre profesión, decido empezar este proyecto para acercar el derecho y sus herramientas a más personas, con el fin de brindar soluciones concretas. Contando con un grupo de notables profesionales en las distintas ramas del derecho, nuestro compromiso es estar en los detalles que cada caso conlleva, haciendo de nosotros un estudio jurídico de excelencia. <br><br>El constante aprendizaje y la perseverancia son nuestros pilares. </p>
										</div>
									</div>
								</div>
								<div class="col">
									<div class="hero-img mt-30 mb-30" data-wow-duration="1.5s" style="visibility: visible; animation-duration: 1.5s; animation-name: fadeInUp;">	
										<img src="img/me.jpg" alt="">
									</div>		
								</div>
							</div>
						</div>
					</div>
				</div>						
			<!-- seccion areas de practica -->
			<div class="container">
				<section class="row" id="areasDePractica">
						<h2 class="section-two">Areas <span>de</span> práctica</h2>
						<p class="col section-two-p">Con el fin de brindarte un servicio integral y de calidad, nuestro equipo también cuenta con profesionales contables y asesores de seguros y planificación financiera. 
							Todos los servicios ofrecidos están pensados para que, de manera interdisciplinaria, podamos defender tus intereses y garantizar el cumplimiento de tus derechos.</p>
				</section>
			</div>		
			<div class="contenedor">	
				<div class="card">
					<div class="card-header" id="dchoPenal"> 
						<img src="img/prisionero.png" alt="Derecho Penal">
					</div>
					<div class="card-body">
						<h4>Derecho Penal</h4>
						<p class="card-text">Denuncias <br> Imputado <br> Parte querellante y Particular damnificado <br>Excarcelaciones <br>Etapa de instrucción <br>Probation <br>Juicio abreviado</p>
					</div>
				</div>	
				<div class="card">
					<div class="card-header" id="dchoCivil">
						<img src="img/linea-de-sucesion.png" alt="Derecho Civil">
					</div>
					<div class="card-body">
						<h4>Derecho Civil y Contractual</h4>
						<p class="card-text">Redacción de contratos <br>Reclamo de daños y perjuicios <br>Prescripción adquisitiva</p>
					</div>
				</div>
				<div class="card">
					<div class="card-header" id="dchoFam">
						<img src="img/house-door.svg" alt="Familia y Sucesiones">
					</div>
					<div class="card-body">
						<h4>Derecho de Familia y Sucesiones</h4>
						<p class="card-text">Violencia familiar <br>Filiación <br>Régimen de alimentos <br>Responsabilidad parental <br>Impugnación de la paternidad </p>
					</div>
				</div>
				<div class="card">
					<div class="card-header" id="dchoSeguros">
						<img src="img/car-front.svg" alt="Seguros y Accidentes de tránsito">
					</div>
					<div class="card-body">
						<h4>Seguros y Accidentes de tránsito</h4>
						<p class="card-text">Reclamos administrativos <br>Intimaciones a empresas de seguros <br>Reclamo de indemnizaciones <br>Lesiones</p>
					</div>
				</div>
				<div class="card">
					<div class="card-header" id="dchoLaboral">
						<img src="img/minecart-loaded.svg" alt="Derecho Laboral">
					</div>
					<div class="card-body">
						<h4>Derecho Laboral</h4>
						<p class="card-text">Despidos <br>Registración correcta del empleado <br>Asesoramiento por falta de pago de aguinaldo y vacaciones</p>
					</div>
				</div>
				<div class="card">
					<div class="card-header" id="dchoAdmin">
						<img src="img/capital.png" alt="Derecho Administrativo">
					</div>
					<div class="card-body">
						<h4>Derecho Administrativo</h4>
						<p class="card-text">Sumarios <br>Cesantías <br>Exoneraciones <br>Reclamo administrativos</p>
					</div>
				</div>
			</div>
			<!-- carrousel -->
			<!-- <div class="container">
				<h2 class="section-two" id="novedades">Novedades</h2>
				<div id="carouselExampleCaptions" class="carousel slide">
					<div class="carousel-indicators">
					  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
					  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
					  <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
					</div>
					<div class="carousel-inner">
					  <div class="carousel-item active">
						<img src="img/rechazoConcursoPrev.png" class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
						  <h5>First slide label</h5>
						  <p>Some representative placeholder content for the first slide.</p>
						</div>
					  </div>
					  <div class="carousel-item">
						<img src="..." class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
						  <h5>Second slide label</h5>
						  <p>Some representative placeholder content for the second slide.</p>
						</div>
					  </div>
					  <div class="carousel-item">
						<img src="..." class="d-block w-100" alt="...">
						<div class="carousel-caption d-none d-md-block">
						  <h5>Third slide label</h5>
						  <p>Some representative placeholder content for the third slide.</p>
						</div>
					  </div>
					</div>
					<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
					  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
					  <span class="visually-hidden">Previous</span>
					</button>
					<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
					  <span class="carousel-control-next-icon" aria-hidden="true"></span>
					  <span class="visually-hidden">Next</span>
					</button>
				  </div> -->
			<!-- seccion de contacto -->
			<div class="container contact" id="contact">
				<h3 class="form-title">Contactanos</h3>
				<div class="row">
						<div id="contactanos" class="contact-form">
							<form class="contact" method="POST">
								<input type="text" id="name" name="name" class="text-box" placeholder="Nombre completo" required>
								<input type="email" id="email" name="email" class="text-box" placeholder="E-mail" required>
								<input type="text" id="direction" name="direction" class="text-box" placeholder="dirección" required>
								<input type="tel" id="phone" name="phone" class="text-box" placeholder="Teléfono" required>
								<textarea id="message" name="message" rows="2" placeholder="Deje su mensaje	" required></textarea>
								<input type="submit" name="contact" class="send-btn" value="Enviar">
							</form>
					</div>	
				</div>
				<h3 class="form-title">Donde encontrarnos</h3>
					<div class="col buttons">	
						<a href="#"><i class="bi bi-facebook"></i></a>
						<a href="https://api.whatsapp.com/send?phone=5491135913161&text=Buenas%2C+estoy+necesitando+asesoramiento+legal+y+quiero+agendar+una+consulta." target="_blank" class="fa-brands fa-whatsapp"><i class="bi bi-whatsapp"></i></a>
						<a href="https://www.instagram.com/beristainyasociados/" target="_blank" class="fa-brands fa-instagram"><i class="bi bi-instagram"></i></a>
						<a href="https://www.linkedin.com/in/leonardo-beristain-61337110a/" target="_blank" class="fa-brands fa-linkedin"><i class="bi bi-linkedin"></i></a>
					</div>
				</div>
			</div>	
	</main>		
		
			<footer>
				<div class="col contact">
					<div><i class="bi bi-geo-alt-fill" style="font-size: 40px; padding: 10px;"></i>
						<p>Villa Luro, CABA, CABA</p>
					</div>
					<div><i class="bi bi-envelope-at-fill" style="font-size: 40px; padding: 10px;"></i>
						<p>beristainyasociadosej@gmail.com</p>
					</div>
					<div><i class="bi bi-phone-vibrate-fill" style="font-size: 40px; padding: 10px;"></i>
						<p>(+54) 011 35913161 // (+54) 011 33528174</p>
					</div>
					<div><i class="bi bi-clock-fill" style="font-size: 40px; padding: 10px;"></i>
						<p>Lunes a viernes de 07.00 a 19.00hs</p>
					</div>
				<p>Tomamos casos en el ámbito de la Ciudad Autónoma de Buenos Aires, La Provincia de Buenos Aires y el fuero Federal.</p>
				<p>Derechos de autor © Beristain & Asociados 2023. Buenos Aires, Argentina.</p>
			</footer>		
	
		<?php
		 
			include("includes/registrar.php");
	 	?>

		<!-- Bootstrap -->
		 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>